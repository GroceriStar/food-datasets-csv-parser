Main task is here: https://github.com/GroceriStar/sd/issues/471

We have a few files, stored at https://github.com/ChickenKyiv/awesome-food-db-strucutures/tree/master/USDA-01-06-2019
