This is from Finland json file

```
[
    {
        "Food class": "Additives, flavours, baking and processing aids",
        "Food (FoodEx2 description)": "Artificial sweeteners (e.g., aspartam, saccharine)",
        "Microgram/100 gram": "",
        "Milligram/100 gram": "",
        "country": "Finland"
    },
    {
        "Food class": "Additives, flavours, baking and processing aids",
        "Food (FoodEx2 description)": "Aspartame",
        "Microgram/100 gram": "0",
        "Milligram/100 gram": "0",
        "country": "Finland"
    },
    {
        "Food class": "Additives, flavours, baking and processing aids",
        "Food (FoodEx2 description)": "Baking yeast",
        "Microgram/100 gram": "1",
        "Milligram/100 gram": "1045.87",
        "country": "Finland"
    },
```

Yes, in data FoodComposition are:

```
├── Food_Composition.csv
├── Food_Composition - Finland.csv
├── Food_Composition - France.csv
├── Food_Composition - Germany.csv
├── Food_Composition - Italy.csv
├── Food_Composition - Netherlands.csv
├── Food_Composition - Sweden.csv
├── Food_Composition - United Kingdom.csv
└── Readme.md

```
