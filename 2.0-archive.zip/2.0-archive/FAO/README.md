Task: https://github.com/GroceriStar/food-datasets-csv-parser/issues/27

Source files: https://github.com/ChickenKyiv/awesome-food-db-strucutures/tree/master/FAO
